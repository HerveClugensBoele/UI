//  <section>
//      <article class="category-header">
//          <span>[CATEGORY TITLE GOES HERE]</span>
//          <i class="material-icons" onclick="toggleStar(this)">star_border</i>
//      </article>
//      <article class="category-paragraph">
//          <p>[CATEGORY INFO GOES HERE]</p>
//      </article>
//  </section>
